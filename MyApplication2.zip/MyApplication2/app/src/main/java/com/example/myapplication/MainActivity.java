package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText mortgageField = findViewById(R.id.mortgage);
        Spinner irDropdown = findViewById(R.id.interestRate);
        Spinner amortDropdown = findViewById(R.id.amortizationP);
        FloatingActionButton link = findViewById(R.id.amortLearnMore);
        FloatingActionButton link2 = findViewById(R.id.rateLearnMore);
        Button calculateButton = findViewById(R.id.calculate);

        String[] rates = new String[]{
                "3.00%",
                "3.50%",
                "4.00%",
                "4.50%",
                "5.00%",
                "5.50%",
                "6.00%",
                "6.50%",
                "7.00%",
                "7.50%",
                "8.00%",
                "8.50%",};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, rates);
        irDropdown.setAdapter(adapter);

        String[] years = new String[]{
                "0.5 years",
                "2 years",
                "3 years",
                "4 years",
                "5 years",
                "6 years",
                "7 years",
                "8 years",
                "9 years",
                "10 years",
                "11 years",
                "12 years",
                "13 years",
                "14 years",
                "15 years",
                "16 years",
                "17 years",
                "18 years",
                "19 years",
                "20 years",
                "21 years",
                "22 years",
                "23 years",
                "24 years",
                "25 years",
                "26 years",
                "27 years",
                "28 years",
                "29 years",
                "30 years"};
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, years);
        amortDropdown.setAdapter(adapter2);

        link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.bdc.ca/en/articles-tools/entrepreneur-toolkit/templates-business-guides/glossary/amortization-expenses#:~:text=Amortization%20definition,the%20lifetime%20of%20their%20use.");
            }
        });

        link2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.investopedia.com/terms/i/interestrate.asp");
            }
        });

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mortgageText = mortgageField.getText().toString();
                double mortgage = Double.parseDouble(mortgageText);
                String irText = irDropdown.getSelectedItem().toString();
                double ir = Double.parseDouble(irText.replaceAll("%", ""));
                String amortText = amortDropdown.getSelectedItem().toString();
                double amortP = Double.parseDouble(amortText.replace(" years", ""));

                double monthlyInterest = (ir / 100 / 12);
                double numberofPayments = amortP * 12;

                double payment = calculate(mortgage, monthlyInterest, numberofPayments);

                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                intent.putExtra("RESULT_KEY", payment);
                startActivity(intent);
            }
        });
    }
    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }

    private double calculate(double mortgage, double monthlyInterest, double numberOfPayments){
        double mathPower = Math.pow(1 + monthlyInterest, numberOfPayments);
        double monthlyPayment = mortgage * (monthlyInterest * mathPower / (mathPower - 1));

        return monthlyPayment;
    }
}