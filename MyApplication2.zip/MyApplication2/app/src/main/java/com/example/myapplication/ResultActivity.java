package com.example.myapplication;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView resultTextView = findViewById(R.id.result);
        Button backButton = findViewById(R.id.back);

        Intent intent = getIntent();
        double payment = intent.getDoubleExtra("RESULT_KEY", 0);
        payment = Math.round(payment * 100.0) / 100.0;

        String resultText = String.format("$%.2f /month", payment); // Formats the payment value with 2 decimal places
        resultTextView.setText(resultText);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Optional: finishes the current activity to free up resources
            }
        });
    }
}
